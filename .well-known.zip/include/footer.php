<!-- <footer class="kilimanjaro_area">
    <!-- Top Footer Area Start -->
    <!-- <div class="foo_top_header_one section_padding_100_70">
        <div class="container" style="max-width: 90%;">
            <div class="row">
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="kilimanjaro_part">
                        <div class="footer-logo">
                            <img src="assets/img/Logo-white.png" alt="logo">
                        </div>
                        <p style="font-weight:bold;font-size:20px">Hoch is much more than a private for-profit academy! We are a social movement!</p>
                    </div>
                    <div class="footer__social">

                                        <h4>Follow Us</h4>

                                        <ul>


                                            <li><a href="https://www.instagram.com/Hochinstitute.academy/"><i class="fa-brands fa-instagram"></i></a></li>

                                            <li><a href="https://www.linkedin.com/company/Hochinstitute-academy-2019/?lipi=urn%3Ali%3Apage%3Ad_flagship3_search_srp_companies%3BvjFNKORbSuqfgqaYpuHgQg%3D%3D"><i class="fa-brands fa-linkedin-in"></i></a></li>

                                            <li><a href="https://wa.link/zhtobg"><i class="fa-brands fa-whatsapp"></i></a></li>

                                        </ul>

                                    </div>

                </div>
                <div class="col-12 col-md-6 col-lg-3">
                    <div class="kilimanjaro_part m-top-15" style="padding-left: 15px;">
                        <h5>Links</h5>
                        <ul class="kilimanjaro_links">
                            <li><a href="about.php" >About</a></li>
                            <li><a href="contact.php" >Services</a></li>
                            <li><a href="index#Pircing" >Get started</a></li>
                            
                        </ul>
                    </div>


                </div>
                <div class="col-12 col-md-6 col-lg-3">
                    <div class="kilimanjaro_part m-top-15">
                        <h5>Terms and Conditions</h5>
                        <ul class="kilimanjaro_links">
                            <li><a href="#" >Terms & Conditions</a></li>
                            <li><a href="Privacy-Policy.php" >Privacy Policy</a></li>
                            <li><a href="#" >Refund Policy</a></li>
                        </ul>
                    </div>

                    <div class="kilimanjaro_part m-top-15">
                        <h5>Contact Us</h5>
                        <ul class="kilimanjaro_links">
                            <li><a href="mailto:contact@Hochinstitute.us"><i class="far fa-envelope"></i> contact@Hochinstitute.com</a></li>
                            <li><a href="#"><i class="fa-sharp fa-solid fa-phone"></i>+1 (206) 201-2259</a></li>
                            <li><a href="#"><i class="fa-sharp fa-solid fa-phone"></i>+1 (206) 201-2259</a></li>
                            <li><a href="#"><i class="far fa-clock"></i> Monday - Saturday</a></li>
                        </ul>
                    </div>
                </div>


            </div>
        </div>
    </div>
    <!-- Footer Bottom Area Start -->
    <!-- <div class=" kilimanjaro_bottom_header_one section_padding_50 text-center">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <p style="font-size: 14px;">Copyright© 2019-2022 Hochinstitute Academy 1617 Monroe St NE Washington, DC 20018 All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </div>
</footer> --> 

<div id="footer">


        <footer id="info">

            <div class="footer__area">

                <div class="footer__top grey-bg-4 pt-4 pb-4 bg-1e2845">

                    <div class="container">

                    <div class="row">

                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-sm-7">

                            <div class="footer__widget footer__widget-2 mb-50">

                                <div class="footer__logo">

                                <div class="logo">

                                    <a href="index.html">

                                        <img src="assets/img/Logo-White.png" alt="">

                                    </a>

                                </div>

                                </div>

                                <div class="footer__widget-content">

                                <div class="footer__widget-info">

                                    <p style="font-weight:bold;font-size:20px">Hoch is much more than a private for-profit institute! We are a social movement!</p>

                                    <div class="footer__social">

                                        <h4>Follow Us</h4>

                                        <ul>


                                            <li><a href="https://www.instagram.com/hoch.institute/"><i class="fa-brands fa-instagram"></i></a></li>

                                            <li><a href="https://hochinstitute.com/404"><i class="fa-brands fa-linkedin-in"></i></a></li>

                                            <li><a href="https://wa.me/message/ZMNTQNMUOYW7D1"><i class="fa-brands fa-whatsapp"></i></a></li>

                                        </ul>

                                    </div>

                                </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-3 col-sm-5 text-center mt-40">

                            <div class="footer__widget footer__widget-2 mb-50 footer-col-2-2">

                                <h3 class="footer__widget-title">Links</h3>

                                <div class="footer__widget-content">

                                <ul>

                                    <li>

                                        <a href="/about">About us</a>

                                    </li>

                                    <li>

                                    <li>

                                        <a href="services.php">Services</a>

                                    </li>

                                    <li>

                                        <a href="contact.php">Get started</a>

                                    </li>

                                </ul>

                                </div>

                            </div>

                        </div>

                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-3 col-sm-5 text-start mt-40">

                            <div class="footer__widget footer__widget-2 mb-50 footer-col-2-2">

                                <h3 class="footer__widget-title">Terms and Conditions</h3>

                                <div class="footer__widget-content">

                                <ul>

                                    <li>

                                        <a href="Tos.php">Terms and Conditions</a>

                                    </li>

                                    <li>

                                        <a href="privacy-policy.php">Privacy Policy</a>

                                    </li>

                                    <li>

                                        <a href="Refund-Policy.php">Refund Policy</a>

                                    </li>

                                </ul>

                                </div>

                                <h3 class="footer__widget-title mt-20">Contact us</h3>

                                <div class="footer__widget-content contact-us">

                                    <ul>

                                        <li>

                                            <a href="mailto:contact@hochinstitute.com"><i class="far fa-envelope"></i> contact@hochinstitute.com</a>
                                        
                                            
                                        </li>

                                        <li>
                                            
                                            <a href="mailto:hiring@hochinstitute.com"><i class="far fa-envelope"></i> hiring@hochinstitute.com</a>
                                        
                                            
                                        </li>

                                        <li>


                                            <a href="#"><i class="fa-sharp fa-solid fa-phone"></i>+49 (155) 108 13113 </a>

                                        </li>

                                        <li>

                                      

                                            <a href="#"><i class="far fa-clock"></i> Monday - Saturday</a>

                                        </li>

                                    </ul>

                                </div>

                            </div>

                        </div>

                    </div>

                    </div>

                </div>

                <div class="footer__bottom grey-bg-4 bg-1e2845">

                    <div class="container">

                    <div class="footer__bottom-inner">

                        <div class="row">

                            <div class="col-xxl-12">

                                <div class="footer__copyright text-left">

                                  <p> Copyright© 2020-2023 Hoch institute An der. Spandauer Brücke 8, 10178 Berlin, Germany All Rights Reserved.
                                </div>

                            </div>

                        </div>

                    </div>

                    </div>

                </div>

            </div>

        </footer>






</div>